jQuery.noConflict();

jQuery(document).ready(function ($) {

	jQuery('#jform_params_asset_js-lbl').parents().eq(1).css('display', 'none');
	jQuery('#jform_params_asset_css-lbl').parents().eq(1).css('display', 'none');
	
});